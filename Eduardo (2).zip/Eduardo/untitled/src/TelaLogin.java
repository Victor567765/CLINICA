import javax.swing.*;
import java.awt.*;

public class TelaLogin extends JPanel {

    public TelaLogin(MainApp app) {

        setLayout(new GridBagLayout());
        setBackground(UIStyle.BG_LIGHT);

        JPanel box = UIStyle.roundedPanel();
        box.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);

        JLabel title = new JLabel("Login da Clínica");
        title.setFont(UIStyle.TITLE_FONT);
        title.setForeground(UIStyle.PRIMARY);

        JTextField user = UIStyle.createTextField(15);
        JPasswordField pass = new JPasswordField(15);
        pass.setFont(UIStyle.LABEL_FONT);

        JButton login = UIStyle.createButton("Entrar");

        login.addActionListener(e -> {
            String username = user.getText();
            String password = new String(pass.getPassword());

            if (username.equals("admin") && password.equals("123")) {
                app.showScreen("home");
            } else {
                JOptionPane.showMessageDialog(this, "Usuário ou senha inválidos.", "Erro de Login", JOptionPane.ERROR_MESSAGE);
            }
        });

        c.gridy = 0; c.gridwidth = 2; box.add(title, c);
        c.gridy = 1; c.gridwidth = 1; box.add(new JLabel("Usuário:"), c);
        c.gridy = 2; box.add(user, c);
        c.gridy = 3; box.add(new JLabel("Senha:"), c);
        c.gridy = 4; box.add(pass, c);
        c.gridy = 5; c.insets.top = 20; box.add(login, c);

        add(box);
    }
}