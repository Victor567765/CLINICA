public class Consulta {
    private Paciente paciente;
    private Medico medico;
    private String dataHora;

    public Consulta(Paciente paciente, Medico medico, String dataHora) {
        this.paciente = paciente;
        this.medico = medico;
        this.dataHora = dataHora;
    }

    public String getDataHora() { return dataHora; } // Adicionado para ordenação

    @Override
    public String toString() {
        return dataHora + " | Dr(a). " + medico.getNome() + " | Paciente: " + paciente.getNome();
    }
}