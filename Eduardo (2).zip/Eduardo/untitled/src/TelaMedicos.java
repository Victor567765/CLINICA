import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import javax.swing.border.EmptyBorder;

public class TelaMedicos extends JPanel {

    private JTable tabela;
    private DefaultTableModel model;
    private MainApp app;

    public TelaMedicos(MainApp app) {
        this.app = app;
        setLayout(new BorderLayout(20, 20));
        setBackground(UIStyle.BG_LIGHT);

        JLabel title = new JLabel("Gestão de Médicos", SwingConstants.CENTER);
        title.setFont(UIStyle.TITLE_FONT);
        title.setForeground(UIStyle.PRIMARY_DARK);
        title.setBorder(new EmptyBorder(20, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        // --- 1. Tabela de Médicos (Centro) ---
        String[] colunas = {"ID", "Nome", "CRM", "Especialidade"};
        model = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Nenhuma célula editável
            }
        };

        tabela = new JTable(model);
        tabela.setFont(UIStyle.LABEL_FONT);
        tabela.setRowHeight(25);
        tabela.setFillsViewportHeight(true);
        tabela.getTableHeader().setFont(UIStyle.SUBTITLE_FONT);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.setAutoCreateRowSorter(true); // Permite ordenação

        refreshTableModel(); // Carrega os dados iniciais

        JPanel listPanel = UIStyle.titledPanel("Lista de Profissionais");
        listPanel.setLayout(new BorderLayout());
        listPanel.add(new JScrollPane(tabela), BorderLayout.CENTER);

        add(listPanel, BorderLayout.CENTER);

        // --- 2. Painel de Cadastro e Ações (Leste) ---
        JPanel actionPanel = criarPainelCadastro();
        add(actionPanel, BorderLayout.EAST);
    }

    private JPanel criarPainelCadastro() {
        JPanel actionPanel = UIStyle.roundedPanel();
        actionPanel.setLayout(new GridBagLayout());
        actionPanel.setPreferredSize(new Dimension(350, getHeight()));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        JLabel addTitle = new JLabel("Cadastrar Novo Médico", SwingConstants.CENTER);
        addTitle.setFont(UIStyle.SUBTITLE_FONT);
        addTitle.setForeground(UIStyle.TEXT_DARK);

        JTextField nome = UIStyle.createTextField(25);
        JTextField crm = UIStyle.createTextField(15);
        JTextField especialidade = UIStyle.createTextField(20);

        JButton add = UIStyle.createActionButton("Cadastrar Médico");
        JButton remove = UIStyle.createDangerButton("Remover Selecionado");
        JButton voltar = UIStyle.createButton("Voltar ao Menu");

        // Ações de Cadastro
        add.addActionListener(e -> {
            String n = nome.getText().trim();
            String c = crm.getText().trim();
            String esp = especialidade.getText().trim();

            if (n.isEmpty() || c.isEmpty() || esp.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Preencha todos os campos para cadastro.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Medico novoMedico = new Medico(n, c, esp);
            app.medicos.add(novoMedico);
            refreshTableModel(); // Atualiza a tabela

            nome.setText("");
            crm.setText("");
            especialidade.setText("");

            try {
                ((TelaConsultas) app.container.getComponent(5)).refreshList();
            } catch (Exception ex) {}

            JOptionPane.showMessageDialog(this, "Médico cadastrado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        });

        // Ações de Remoção
        remove.addActionListener(e -> {
            int viewRow = tabela.getSelectedRow();
            if (viewRow != -1) {
                // Mapeia a linha selecionada da visão (ordenada) para o modelo (ArrayList)
                int modelRow = tabela.convertRowIndexToModel(viewRow);

                Medico medicoToRemove = app.medicos.get(modelRow);
                app.medicos.remove(modelRow);

                refreshTableModel(); // Atualiza a tabela

                try {
                    ((TelaConsultas) app.container.getComponent(5)).refreshList();
                } catch (Exception ex) {}

                JOptionPane.showMessageDialog(this, "Médico removido: " + medicoToRemove.getNome(), "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Selecione um médico para remover.", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });

        voltar.addActionListener(e -> app.showScreen("home"));


        // Adiciona componentes
        gbc.gridy = 0; gbc.ipady = 10; actionPanel.add(addTitle, gbc);
        gbc.gridy = 1; gbc.ipady = 0; actionPanel.add(new JLabel("Nome Completo:"), gbc);
        gbc.gridy = 2; actionPanel.add(nome, gbc);
        gbc.gridy = 3; gbc.insets.top = 10; actionPanel.add(new JLabel("CRM:"), gbc);
        gbc.gridy = 4; gbc.insets.top = 5; actionPanel.add(crm, gbc);
        gbc.gridy = 5; gbc.insets.top = 10; actionPanel.add(new JLabel("Especialidade:"), gbc);
        gbc.gridy = 6; gbc.insets.top = 5; actionPanel.add(especialidade, gbc);

        gbc.gridy = 7; gbc.insets = new Insets(20, 5, 5, 5); actionPanel.add(add, gbc);

        gbc.gridy = 8; gbc.insets = new Insets(20, 5, 5, 5); actionPanel.add(new JSeparator(), gbc);

        gbc.gridy = 9; gbc.insets = new Insets(5, 5, 5, 5); actionPanel.add(remove, gbc);

        gbc.gridy = 10; gbc.weighty = 1.0; actionPanel.add(new JLabel(""), gbc);

        gbc.gridy = 11; gbc.weighty = 0; gbc.insets.bottom = 0; actionPanel.add(voltar, gbc);

        return actionPanel;
    }

    // Método para recarregar os dados do ArrayList na JTable
    private void refreshTableModel() {
        model.setRowCount(0); // Limpa todos os dados

        for (Medico medico : app.medicos) {
            model.addRow(new Object[]{
                    medico.getId(),
                    medico.getNome(),
                    medico.getCrm(),
                    medico.getEspecialidade()
            });
        }
    }
}