public class Medico {
    private static int nextId = 1;
    private int id;
    private String nome;
    private String crm;
    private String especialidade;

    public Medico(String nome, String crm, String especialidade) {
        this.id = nextId++;
        this.nome = nome;
        this.crm = crm;
        this.especialidade = especialidade;
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getCrm() { return crm; }
    public String getEspecialidade() { return especialidade; }

    @Override
    public String toString() {
        return id + " | " + nome + " (CRM: " + crm + " - " + especialidade + ")";
    }
}