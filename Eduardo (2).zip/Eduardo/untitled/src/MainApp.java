import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class MainApp extends JFrame {

    CardLayout layout = new CardLayout();
    public JPanel container = new JPanel(layout);

    public ArrayList<EstoqueItem> estoque = new ArrayList<>();
    public ArrayList<Paciente> pacientes = new ArrayList<>();
    public ArrayList<Medico> medicos = new ArrayList<>();
    public ArrayList<Consulta> consultas = new ArrayList<>();

    public MainApp() {

        setTitle("Sistema Clínica Médica");
        setSize(1024, 768);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // --- Dados Iniciais Mock ---
        estoque.add(new EstoqueItem("Soro Fisiológico", 50));
        medicos.add(new Medico("Dra. Clara Souza", "CRM-SP 12345", "Cardiologia"));
        medicos.add(new Medico("Dr. João Almeida", "CRM-RJ 67890", "Pediatria"));
        pacientes.add(new Paciente("Ana Silva", "111.222.333-44"));
        pacientes.add(new Paciente("Bruno Costa", "555.666.777-88"));

        if (!pacientes.isEmpty() && !medicos.isEmpty()) {
            consultas.add(new Consulta(pacientes.get(0), medicos.get(0), "2025-12-01 10:00"));
        }
        // --- Fim Dados Iniciais Mock ---

        container.setBackground(UIStyle.BG_LIGHT);

        // Ordem das Telas (O índice 5 é usado para o refresh da Agenda):
        container.add(new TelaLogin(this), "login");       // 0
        container.add(new TelaHome(this), "home");         // 1
        container.add(new TelaEstoque(this), "estoque");   // 2
        container.add(new TelaPacientes(this), "pacientes");// 3
        container.add(new TelaMedicos(this), "medicos");   // 4
        container.add(new TelaConsultas(this), "consultas");// 5
        container.add(new TelaSobre(this), "sobre");       // 6

        setContentPane(container);
        setVisible(true);

        showScreen("login");
    }

    public void showScreen(String name) {
        layout.show(container, name);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        SwingUtilities.invokeLater(MainApp::new);
    }
}