import javax.swing.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;

public class TelaSobre extends JPanel {

    public TelaSobre(MainApp app) {

        setLayout(new BorderLayout(20, 20));
        setBackground(UIStyle.BG_LIGHT);

        JLabel title = new JLabel("Sobre o Sistema", SwingConstants.CENTER);
        title.setFont(UIStyle.TITLE_FONT);
        title.setForeground(UIStyle.PRIMARY_DARK);
        title.setBorder(new EmptyBorder(20, 0, 10, 0));

        JPanel infoPanel = UIStyle.roundedPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setBorder(new EmptyBorder(30, 50, 30, 50));

        JTextArea txt = new JTextArea(
                "Sistema de Clínica Médica\n\n" +
                        "Versão 1.0 - Totalmente funcional (MVP)\n\n" +
                        "Recursos:\n" +
                        "• Login Simples (admin/123)\n" +
                        "• Menu de Navegação Lateral\n" +
                        "• Cadastro, Listagem e Remoção de Pacientes\n" +
                        "• Cadastro, Listagem e Remoção de Médicos\n" +
                        "• Controle de Estoque com Tabela (Adicionar/Remover)\n" +
                        "• Agenda de Consultas (Seletor de Data/Hora)"
        );
        txt.setEditable(false);
        txt.setFont(UIStyle.LABEL_FONT);
        txt.setBackground(Color.WHITE);
        txt.setAlignmentX(Component.CENTER_ALIGNMENT);

        infoPanel.add(txt);

        JPanel centerWrapper = new JPanel(new GridBagLayout());
        centerWrapper.setBackground(UIStyle.BG_LIGHT);
        centerWrapper.add(infoPanel);

        JButton voltar = UIStyle.createButton("Voltar ao Menu"); // NOVO BOTÃO
        voltar.addActionListener(e -> app.showScreen("home"));

        add(title, BorderLayout.NORTH);
        add(centerWrapper, BorderLayout.CENTER);
        add(voltar, BorderLayout.SOUTH); // Adicionado aqui
    }
}