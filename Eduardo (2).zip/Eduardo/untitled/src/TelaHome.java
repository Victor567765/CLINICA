import javax.swing.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;

public class TelaHome extends JPanel {

    private MainApp app;

    public TelaHome(MainApp app) {
        this.app = app;
        setLayout(new BorderLayout());
        setBackground(UIStyle.BG_LIGHT);

        JPanel menuPanel = createSideMenu();
        add(menuPanel, BorderLayout.WEST);

        JPanel contentPanel = createContentPanel();
        add(contentPanel, BorderLayout.CENTER);
    }

    private JPanel createSideMenu() {
        JPanel menu = new JPanel();
        menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));
        menu.setBackground(UIStyle.PRIMARY_DARK);
        menu.setPreferredSize(new Dimension(220, getHeight()));
        menu.setBorder(new EmptyBorder(10, 0, 10, 0));

        JLabel title = new JLabel("ClínicaApp");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setBorder(new EmptyBorder(15, 0, 30, 0));
        menu.add(title);

        addButton(menu, "Início", "home");
        addButton(menu, "Agenda de Consultas", "consultas");
        addButton(menu, "Pacientes", "pacientes");
        addButton(menu, "Médicos", "medicos");
        addButton(menu, "Estoque", "estoque");

        menu.add(Box.createVerticalGlue());

        addButton(menu, "Sobre", "sobre");
        addButton(menu, "Sair", "login", UIStyle.ACCENT_RED);

        return menu;
    }

    private void addButton(JPanel menu, String text, String screenName) {
        addButton(menu, text, screenName, null);
    }

    private void addButton(JPanel menu, String text, String screenName, Color customColor) {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFocusPainted(false);
        button.setMaximumSize(new Dimension(200, 45));
        button.setMinimumSize(new Dimension(200, 45));
        button.setPreferredSize(new Dimension(200, 45));

        button.setBackground(customColor != null ? customColor : UIStyle.PRIMARY);
        button.setForeground(Color.WHITE);
        button.setFont(UIStyle.BUTTON_FONT);
        button.setBorder(new EmptyBorder(10, 10, 10, 10));

        button.addActionListener(e -> app.showScreen(screenName));

        menu.add(button);
        menu.add(Box.createVerticalStrut(10));
    }

    private JPanel createContentPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(UIStyle.BG_LIGHT);
        panel.setBorder(new EmptyBorder(30, 30, 30, 30));

        JPanel welcomeBox = UIStyle.roundedPanel();
        welcomeBox.setLayout(new BoxLayout(welcomeBox, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("Olá!");
        title.setFont(UIStyle.TITLE_FONT);
        title.setForeground(UIStyle.PRIMARY_DARK);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel welcomeText = new JLabel("Bem-vindo ao Painel Principal do Sistema Clínica Médica.");
        welcomeText.setFont(UIStyle.LABEL_FONT);
        welcomeText.setBorder(new EmptyBorder(10, 0, 20, 0));
        welcomeText.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton btnQuickAccess = UIStyle.createActionButton("Acessar Agenda de Consultas");
        btnQuickAccess.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnQuickAccess.addActionListener(e -> app.showScreen("consultas"));

        welcomeBox.add(title);
        welcomeBox.add(welcomeText);
        welcomeBox.add(btnQuickAccess);

        welcomeBox.setPreferredSize(new Dimension(400, 200));

        panel.add(welcomeBox);
        return panel;
    }
}