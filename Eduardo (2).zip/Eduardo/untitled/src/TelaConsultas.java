import javax.swing.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;
import com.toedter.calendar.JDateChooser;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Collections;

public class TelaConsultas extends JPanel {

    private DefaultListModel<Consulta> model;
    private JList<Consulta> lista;
    private MainApp app;

    private JDateChooser dateChooser;
    private JComboBox<String> hourCombo;
    private JComboBox<Medico> comboMedico;
    private JComboBox<Paciente> comboPaciente;

    public TelaConsultas(MainApp app) {
        this.app = app;
        setLayout(new BorderLayout(20, 20));
        setBackground(UIStyle.BG_LIGHT);

        JLabel titulo = new JLabel("Agenda de Consultas", SwingConstants.CENTER);
        titulo.setFont(UIStyle.TITLE_FONT);
        titulo.setForeground(UIStyle.PRIMARY_DARK);
        titulo.setBorder(new EmptyBorder(20, 0, 10, 0));
        add(titulo, BorderLayout.NORTH);

        model = new DefaultListModel<>();
        refreshListModel();

        lista = new JList<>(model);
        lista.setFont(UIStyle.LABEL_FONT);
        lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel listPanel = UIStyle.titledPanel("Próximas Consultas Agendadas");
        listPanel.setLayout(new BorderLayout());
        listPanel.add(new JScrollPane(lista), BorderLayout.CENTER);

        add(listPanel, BorderLayout.CENTER);

        JPanel actionPanel = criarPainelAgendamento();
        add(actionPanel, BorderLayout.EAST);
    }

    private JPanel criarPainelAgendamento() {
        JPanel actionPanel = UIStyle.roundedPanel();
        actionPanel.setLayout(new GridBagLayout());
        actionPanel.setPreferredSize(new Dimension(350, getHeight()));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        JLabel addTitle = new JLabel("Novo Agendamento", SwingConstants.CENTER);
        addTitle.setFont(UIStyle.SUBTITLE_FONT);
        addTitle.setForeground(UIStyle.TEXT_DARK);

        comboMedico = new JComboBox<>(app.medicos.toArray(new Medico[0]));
        comboPaciente = new JComboBox<>(app.pacientes.toArray(new Paciente[0]));

        dateChooser = new JDateChooser(new Date());
        dateChooser.setDateFormatString("dd/MM/yyyy");
        dateChooser.setFont(UIStyle.LABEL_FONT);

        hourCombo = new JComboBox<>(generateTimeSlots());
        hourCombo.setFont(UIStyle.LABEL_FONT);

        JButton agendar = UIStyle.createActionButton("Agendar Consulta");
        JButton remover = UIStyle.createDangerButton("Remover Consulta");
        JButton voltar = UIStyle.createButton("Voltar ao Menu"); // NOVO BOTÃO

        // Ações de Agendamento
        agendar.addActionListener(e -> {
            Medico medicoSelecionado = (Medico) comboMedico.getSelectedItem();
            Paciente pacienteSelecionado = (Paciente) comboPaciente.getSelectedItem();
            Date dataSelecionada = dateChooser.getDate();
            String horaSelecionada = (String) hourCombo.getSelectedItem();

            if (medicoSelecionado == null || pacienteSelecionado == null || dataSelecionada == null) {
                JOptionPane.showMessageDialog(this, "Selecione um médico, paciente, data e hora válidos.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String dataFormatada = sdf.format(dataSelecionada) + " " + horaSelecionada;

            Consulta novaConsulta = new Consulta(pacienteSelecionado, medicoSelecionado, dataFormatada);
            app.consultas.add(novaConsulta);

            refreshListModel();

            JOptionPane.showMessageDialog(this, "Consulta agendada para " + dataFormatada + "!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        });

        // Ações de Remoção
        remover.addActionListener(e -> {
            int index = lista.getSelectedIndex();
            if (index != -1) {
                Consulta consultaToRemove = model.getElementAt(index);

                app.consultas.remove(consultaToRemove);
                model.remove(index);

                JOptionPane.showMessageDialog(this, "Consulta removida.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Selecione uma consulta para remover.", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });

        voltar.addActionListener(e -> app.showScreen("home")); // Ação de voltar


        // Adiciona componentes ao painel
        gbc.gridy = 0; gbc.ipady = 10; actionPanel.add(addTitle, gbc);

        gbc.gridy = 1; gbc.ipady = 0; actionPanel.add(new JLabel("Médico:"), gbc);
        gbc.gridy = 2; actionPanel.add(comboMedico, gbc);

        gbc.gridy = 3; gbc.insets.top = 10; actionPanel.add(new JLabel("Paciente:"), gbc);
        gbc.gridy = 4; gbc.insets.top = 5; actionPanel.add(comboPaciente, gbc);

        gbc.gridy = 5; gbc.insets.top = 10; actionPanel.add(new JLabel("Data:"), gbc);
        gbc.gridy = 6; gbc.insets.top = 5; actionPanel.add(dateChooser, gbc);

        gbc.gridy = 7; gbc.insets.top = 10; actionPanel.add(new JLabel("Hora:"), gbc);
        gbc.gridy = 8; gbc.insets.top = 5; actionPanel.add(hourCombo, gbc);

        gbc.gridy = 9; gbc.insets = new Insets(20, 5, 5, 5); actionPanel.add(agendar, gbc);

        gbc.gridy = 10; gbc.insets = new Insets(20, 5, 5, 5); actionPanel.add(new JSeparator(), gbc);

        gbc.gridy = 11; gbc.insets = new Insets(5, 5, 5, 5); actionPanel.add(remover, gbc);

        gbc.gridy = 12; gbc.weighty = 1.0; actionPanel.add(new JLabel(""), gbc);

        gbc.gridy = 13; gbc.weighty = 0; gbc.insets.bottom = 0; actionPanel.add(voltar, gbc); // Botão Voltar

        return actionPanel;
    }

    private String[] generateTimeSlots() {
        String[] slots = new String[24];
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 8);
        cal.set(Calendar.MINUTE, 0);

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");

        for (int i = 0; i < 24; i++) {
            slots[i] = sdf.format(cal.getTime());
            cal.add(Calendar.MINUTE, 30);
        }
        return slots;
    }

    private void refreshListModel() {
        Collections.sort(app.consultas, Comparator.comparing(Consulta::getDataHora));

        model.clear();
        for (Consulta c : app.consultas) {
            model.addElement(c);
        }
    }

    public void refreshList() {
        Medico selectedM = (Medico) comboMedico.getSelectedItem();
        Paciente selectedP = (Paciente) comboPaciente.getSelectedItem();

        comboMedico.setModel(new DefaultComboBoxModel<>(app.medicos.toArray(new Medico[0])));
        comboPaciente.setModel(new DefaultComboBoxModel<>(app.pacientes.toArray(new Paciente[0])));

        comboMedico.setSelectedItem(selectedM);
        comboPaciente.setSelectedItem(selectedP);

        refreshListModel();
    }
}