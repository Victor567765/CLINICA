public class Paciente {
    private static int nextId = 1;
    private int id;
    private String nome;
    private String cpf;

    public Paciente(String nome, String cpf) {
        this.id = nextId++;
        this.nome = nome;
        this.cpf = cpf;
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getCpf() { return cpf; }

    @Override
    public String toString() {
        return id + " | " + nome + " (CPF: " + cpf + ")";
    }
}