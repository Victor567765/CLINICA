import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import javax.swing.border.EmptyBorder;

public class TelaEstoque extends JPanel {

    private JTable tabela;
    private DefaultTableModel model;
    private MainApp app;

    public TelaEstoque(MainApp app) {
        this.app = app;
        setLayout(new BorderLayout(20, 20));
        setBackground(UIStyle.BG_LIGHT);

        JLabel title = new JLabel("Controle de Estoque", SwingConstants.CENTER);
        title.setFont(UIStyle.TITLE_FONT);
        title.setForeground(UIStyle.PRIMARY_DARK);
        title.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        // 1. Tabela de Itens (Centro)
        String[] colunas = {"ID", "Nome do Item", "Quantidade"};
        model = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0;
            }
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return columnIndex == 2 ? Integer.class : String.class;
            }
        };

        tabela = new JTable(model);
        tabela.setFont(UIStyle.LABEL_FONT);
        tabela.setRowHeight(25);
        tabela.setFillsViewportHeight(true);
        tabela.getTableHeader().setFont(UIStyle.SUBTITLE_FONT);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.setAutoCreateRowSorter(true);

        refreshTableModel();

        JPanel listPanel = UIStyle.titledPanel("Itens em Estoque");
        listPanel.setLayout(new BorderLayout());
        listPanel.add(new JScrollPane(tabela), BorderLayout.CENTER);

        add(listPanel, BorderLayout.CENTER);

        // 2. Painel de Ações (Leste)
        JPanel actionPanel = criarPainelAcoes();
        add(actionPanel, BorderLayout.EAST);
    }

    private JPanel criarPainelAcoes() {
        JPanel actionPanel = UIStyle.roundedPanel();
        actionPanel.setLayout(new GridBagLayout());
        actionPanel.setPreferredSize(new Dimension(300, getHeight()));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        JLabel addTitle = new JLabel("Adicionar Novo Item", SwingConstants.CENTER);
        addTitle.setFont(UIStyle.SUBTITLE_FONT);
        addTitle.setForeground(UIStyle.TEXT_DARK);

        JTextField nome = UIStyle.createTextField(20);
        JTextField qtd = UIStyle.createTextField(10);

        JButton add = UIStyle.createActionButton("Adicionar Item");
        JButton remove = UIStyle.createDangerButton("Remover Selecionado");
        JButton voltar = UIStyle.createButton("Voltar ao Menu"); // NOVO BOTÃO

        add.addActionListener(e -> {
            try {
                String n = nome.getText().trim();
                int q = Integer.parseInt(qtd.getText().trim());

                if (n.isEmpty() || q <= 0) {
                    JOptionPane.showMessageDialog(this, "Preencha o nome e a quantidade deve ser positiva.", "Erro", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                app.estoque.add(new EstoqueItem(n, q));
                refreshTableModel();

                nome.setText("");
                qtd.setText("");

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Quantidade inválida. Insira um número inteiro.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        remove.addActionListener(e -> {
            int viewRow = tabela.getSelectedRow();

            if (viewRow != -1) {
                int modelRow = tabela.convertRowIndexToModel(viewRow);

                app.estoque.remove(modelRow);

                refreshTableModel();

                JOptionPane.showMessageDialog(this, "Item removido com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Selecione um item para remover.", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });

        voltar.addActionListener(e -> app.showScreen("home")); // Ação de voltar

        // Adicionando componentes
        gbc.gridy = 0; gbc.ipady = 10; actionPanel.add(addTitle, gbc);
        gbc.gridy = 1; gbc.ipady = 0; actionPanel.add(new JLabel("Nome:"), gbc);
        gbc.gridy = 2; actionPanel.add(nome, gbc);
        gbc.gridy = 3; gbc.insets.top = 10; actionPanel.add(new JLabel("Quantidade:"), gbc);
        gbc.gridy = 4; gbc.insets.top = 5; actionPanel.add(qtd, gbc);
        gbc.gridy = 5; gbc.insets = new Insets(20, 5, 5, 5); actionPanel.add(add, gbc);

        gbc.gridy = 6; gbc.insets = new Insets(20, 5, 5, 5); actionPanel.add(new JSeparator(), gbc);

        gbc.gridy = 7; gbc.insets = new Insets(5, 5, 5, 5); actionPanel.add(remove, gbc);

        gbc.gridy = 8; gbc.weighty = 1.0; actionPanel.add(new JLabel(""), gbc);

        gbc.gridy = 9; gbc.weighty = 0; gbc.insets.bottom = 0; actionPanel.add(voltar, gbc); // Botão Voltar

        return actionPanel;
    }

    private void refreshTableModel() {
        model.setRowCount(0);

        int id = 1;
        for (EstoqueItem item : app.estoque) {
            model.addRow(new Object[]{
                    id++,
                    item.getNome(),
                    item.getQuantidade()
            });
        }
    }
}