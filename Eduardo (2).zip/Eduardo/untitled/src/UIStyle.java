import javax.swing.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.CompoundBorder;

public class UIStyle {

    public static final Color PRIMARY = new Color(10, 117, 194);
    public static final Color PRIMARY_DARK = new Color(6, 82, 135);
    public static final Color BG_LIGHT = new Color(240, 242, 245);
    public static final Color TEXT_DARK = new Color(40, 40, 40);
    public static final Color ACCENT_GREEN = new Color(46, 204, 113);
    public static final Color ACCENT_RED = new Color(231, 76, 60);

    public static Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 28);
    public static Font SUBTITLE_FONT = new Font("Segoe UI", Font.BOLD, 18);
    public static Font LABEL_FONT = new Font("Segoe UI", Font.PLAIN, 16);
    public static Font BUTTON_FONT = new Font("Segoe UI", Font.BOLD, 16);

    public static JButton createButton(String text) {
        JButton b = new JButton(text);
        b.setFocusPainted(false);
        b.setBackground(PRIMARY);
        b.setForeground(Color.WHITE);
        b.setFont(BUTTON_FONT);
        b.setBorder(new EmptyBorder(12, 25, 12, 25));
        return b;
    }

    public static JButton createActionButton(String text) {
        JButton b = createButton(text);
        b.setBackground(ACCENT_GREEN);
        return b;
    }

    public static JButton createDangerButton(String text) {
        JButton b = createButton(text);
        b.setBackground(ACCENT_RED);
        return b;
    }

    public static JPanel roundedPanel() {
        JPanel p = new JPanel();
        p.setBackground(Color.WHITE);

        LineBorder innerBorder = new LineBorder(new Color(230, 230, 230), 1);
        EmptyBorder outerBorder = new EmptyBorder(20, 20, 20, 20);
        p.setBorder(new CompoundBorder(innerBorder, outerBorder));

        return p;
    }

    public static JPanel titledPanel(String titleText) {
        JPanel panel = roundedPanel();
        panel.setLayout(new BorderLayout());

        JLabel title = new JLabel(titleText);
        title.setFont(SUBTITLE_FONT);
        title.setBorder(new EmptyBorder(0, 0, 15, 0));
        title.setForeground(PRIMARY_DARK);

        panel.add(title, BorderLayout.NORTH);

        return panel;
    }

    public static JTextField createTextField(int columns) {
        JTextField field = new JTextField(columns);
        field.setFont(LABEL_FONT);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        return field;
    }
}