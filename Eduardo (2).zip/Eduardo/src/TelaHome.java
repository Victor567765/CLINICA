
import javax.swing.*;
import java.awt.*;

public class TelaHome extends JPanel {
    public TelaHome(MainApp app) {
        setLayout(new GridLayout(5,1));

        JButton f1 = new JButton("Tela 1");
        JButton f2 = new JButton("Tela 2");
        JButton f3 = new JButton("Tela 3");
        JButton f4 = new JButton("Tela 4");

        f1.addActionListener(e -> app.showScreen("func1"));
        f2.addActionListener(e -> app.showScreen("func2"));
        f3.addActionListener(e -> app.showScreen("func3"));
        f4.addActionListener(e -> app.showScreen("func4"));

        add(f1);
        add(f2);
        add(f3);
        add(f4);
    }
}
