import javax.swing.*;
import java.awt.*;

public class TelaFunc3 extends JPanel {

    public TelaFunc3(MainApp app) {
        setLayout(new BorderLayout());

        JLabel lbl = new JLabel("Funcionalidade 3", SwingConstants.CENTER);
        lbl.setFont(new Font("Arial", Font.BOLD, 22));

        JButton back = new JButton("Voltar");
        back.addActionListener(e -> app.showScreen("home"));

        add(lbl, BorderLayout.CENTER);
        add(back, BorderLayout.SOUTH);
    }
}
