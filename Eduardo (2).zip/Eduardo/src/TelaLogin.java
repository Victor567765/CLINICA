import javax.swing.*;
import java.awt.*;

public class TelaHome extends JPanel {

    public TelaHome(MainApp app) {

        setLayout(new BorderLayout());

        JLabel titulo = new JLabel("Menu Principal", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 22));

        add(titulo, BorderLayout.NORTH);

        JPanel botoes = new JPanel(new GridLayout(4,1,10,10));

        JButton f1 = new JButton("Funcionalidade 1");
        JButton f2 = new JButton("Funcionalidade 2");
        JButton f3 = new JButton("Funcionalidade 3");
        JButton f4 = new JButton("Funcionalidade 4");

        f1.addActionListener(e -> app.showScreen("func1"));
        f2.addActionListener(e -> app.showScreen("func2"));
        f3.addActionListener(e -> app.showScreen("func3"));
        f4.addActionListener(e -> app.showScreen("func4"));

        botoes.add(f1);
        botoes.add(f2);
        botoes.add(f3);
        botoes.add(f4);

        add(botoes, BorderLayout.CENTER);
    }
}
