import javax.swing.*;
import java.awt.*;

public class MainApp extends JFrame {

    private CardLayout card;
    private JPanel screens;

    public MainApp() {
        setTitle("Sistema Apresentação");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        card = new CardLayout();
        screens = new JPanel(card);

        // Telas
        screens.add(new TelaLogin(this), "login");
        screens.add(new TelaHome(this), "home");
        screens.add(new TelaFunc1(this), "func1");
        screens.add(new TelaFunc2(this), "func2");
        screens.add(new TelaFunc3(this), "func3");
        screens.add(new TelaFunc4(this), "func4");

        add(screens);
        showScreen("login");
    }

    public void showScreen(String name) {
        card.show(screens, name);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainApp().setVisible(true));
    }
}
